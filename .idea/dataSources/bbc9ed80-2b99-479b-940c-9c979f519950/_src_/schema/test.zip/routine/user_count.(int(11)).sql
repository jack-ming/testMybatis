CREATE PROCEDURE user_count(IN sex_id INT, OUT user_count INT)
  BEGIN
IF sex_id=0 THEN
select count(*) from test.p_user where p_user.sex='女' into user_count;
ELSE
select count(*) from test.p_user where p_user.sex='男' into user_count;
end IF;
END;
